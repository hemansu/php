<?php 
/**
* 
*/
class ONE  {

    function globe (){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname="demo";
// Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

    // $sql = "SELECT employeeName, gender, BirthDate,Address,
    // City,Province ,Postalcode,Emailaddress,websitelink,Joiningdate, Annualbasicpay FROM demo";


        $sql = "SELECT * FROM `employees`";
        $this->result = $conn->query($sql);
        return $this->result;
    }

    function checkConnection() {

       $servername = "localhost";
       $username = "root";
       $password = "";
       $dbname="demo";
// Create connection
       $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
       if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

}

function CreateDB(){
  
    $servername = "localhost";
    $username = "root";
    $password = "";
// Create connection
    $conn = new mysqli($servername, $username, $password);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $sql = "CREATE DATABASE demo";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully";
    }
    else
    {
        echo  "Error creating database: " . $conn->error;
}// use database
$sql=" USE demo";
if ($conn->query($sql) === TRUE) {
    echo "Databse change successfully";

}
else
{
    echo  "Error using database: " . $conn->error;
}

}

function CreateTB(){


    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname="demo";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

  //create table
name, address, salary, gender, birthDate, email, website, joiningDate
    $sql="CREATE TABLE employees(". "employeeId int(10) AUTO_INCREMENT PRIMARY KEY,"
       ."employeeName varchar(40),"."gender varchar(6),"."birthDate varchar(10),".
       "Address varchar(60),"." email varchar(60),"." website varchar(60),"."
       joiningDate varchar(60),)";
if ($conn->query($sql) === TRUE) {
    echo "Table Employee_Table created successfully";

}
else
{
    echo  "Error creating table : " . $conn->error;
}
$conn->close();

}

function Insert(){

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname="demo";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

// prepare and bind
    $stmt = $conn->prepare("INSERT INTO employees (employeeName, gender, BirthDate,Address,City,Province,Postalcode,
        Emailaddress,websitelink,Joiningdate,Annualbasicpay) VALUES (?, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $employeeName, $gender, $BirthDate,$Address,$City,$Province,$Postalcode,
        $Emailaddress,$websitelink,$Joiningdate,$Annualbasicpay);
// set parameters and execute
    $employeeName ="Rohan";
    $gender ="Male";
    $BirthDate = "15-09-1992";
    $Address = "431, Letty ave";
    $City ="Brampton";
    $Province ="On";
    $Postalcode = "L6Y5E3";
    $Emailaddress ="rohan@gmail.com";
    $websitelink ="www.rohan.co.in";
    $Joiningdate ="12-01-2004";
    $Annualbasicpay= "$20000"; 
    $stmt->execute();



    echo "New records created successfully";

//$stmt->close();
    $conn->close();

}
function SelectAll(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname="EmployeeDB";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // $sql = "SELECT employeeName, gender, BirthDate,Address,
    // City,Province ,Postalcode,Emailaddress,websitelink,Joiningdate, Annualbasicpay FROM EmployeeDB";


    $sql = "SELECT * FROM `employees`";
    $result = $conn->query($sql);
    ?>

    <table border = 1;
    border-spacing: 5px;
    border-color: black;
    width=100%;>





    <tr>
        <th>employeeId</th>
        <th>employeeName</th>
        <th>gender</th>
        <th>BirthDate</th>
        <th>Address</th>
        <th>City</th>
        <th>Province</th>
        <th>Postalcode</th>
        <th>Emailaddress</th>
        <th>websitelink</th>
        <th>Joiningdate</th>
        <th>Annualbasicpay</th>
    </tr>

    <?php 
    if ($result->num_rows > 0) {
    // output data of each row
        while($row = $result->fetch_assoc()) {


           echo "<tr>";
           echo "<td>";
           echo $row["employeeId"];
           echo "</td>";
           echo "<td>";
           echo $row['employeeName'];
           echo "</td>";
           echo "<td>";
           echo $row['gender'];
           echo "</td>";
           echo "<td>";
           echo $row['BirthDate'];
           echo "</td>";
           echo "<td>";
           echo $row['Address'];
           echo "</td>";
           echo "<td>";
           echo $row['City'];
           echo "</td>";
           echo "<td>";
           echo $row['Province'];
           echo "</td>";
           echo "<td>";
           echo $row['Postalcode'];
           echo "</td>";
           echo "<td>";
           echo $row['Emailaddress'];
           echo "</td>";
           echo "<td>";
           echo $row['websitelink'];
           echo "</td>";
           echo "<td>";
           echo $row['Joiningdate'];
           echo "</td>";
           echo "<td>";
           echo $row['Annualbasicpay'];
           echo "</td>";
           // echo "<td>";
           // echo "<input type='button' name ='Update' value ='Update' onclick=update()>";
           // echo "</td>";
           // echo "<td>";
           // echo "<input type ='button' name = 'Delete' value ='Delete' onclick=delete()> ";
           // echo "</td>";
           // echo "<td>";
           // echo "<input type ='button' name = 'payslip' value ='payslip' onclick=payslip()> ";
           // echo "</td>";
           echo "</tr>";

       }
   } 
   else {
       echo "0 results";
   }        
    //$stmt->close();
    $conn->close();
    ?>

</table>
<?php
            // echo "id: " . $row["employeeId"]. " - Name: " . $row["employeeName"]. " " . $row["gender"]. " " .
            // $row["BirthDate"]. " " . $row["Address"]. " " . $row["City"]. " " . $row["Province"]. " " .
            // $row["Postalcode"]. " " . $row["Emailaddress"]. " " . $row["websitelink"]. 
            // $row["Joiningdate"]. " " . $row["Annualbasicpay"]. " " . "<br>";
}



 function Delete(){

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM demo WHERE id=3";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();

}


function Update(){

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "demo";

// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "UPDATE EmployeeDB SET lastname='Doe' WHERE id=2";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
}

?>