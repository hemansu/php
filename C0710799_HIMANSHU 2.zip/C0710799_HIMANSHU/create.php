<?php
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$name = $address = $salary = $gender = $birthDate = $email =$website =$joiningDate = "";
$name_err = $address_err = $salary_err = $gender_err = $birthDate_err = $email_err =$website_err =$joiningDate_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var(trim($_POST["name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $name_err = 'Please enter a valid name.';
    } else{
        $name = $input_name;
    }
    
    // Validate address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = 'Please enter an address.';     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = 'Please enter a positive integer value.';
    } else{
        $salary = $input_salary;
    }

    //validate gender
        $input_gender = trim($_POST["gender"]);
        if (empty($input_gender)) {
    $gender_err = "Gender is required";
  } else {
    $gender = $input_gender;
  }

   // Validate birthDate
    $input_birthDate = trim($_POST["birthDate"]);
    if(empty($input_birthDate)){
        $birthDate_err = 'Please enter an birthDate.';     
    } else{
        $birthDate = $input_birthDate;
    }

     // Validate email
    $input_email = trim($_POST["email"]);
    if(empty($input_email)){
        $email_err = 'Please enter an email.';     
    } else{
        $email = $input_email;
    }

     // Validate website
    $input_website = trim($_POST["website"]);
    if(empty($input_website)){
        $website_err = 'Please enter an website.';     
    } else{
        $website = $input_website;
    }

     // Validate joiningDate
    $input_joiningDate = trim($_POST["joiningDate"]);
    if(empty($input_joiningDate)){
        $joiningDate_err = 'Please enter an joiningDate.';     
    } else{
        $joiningDate = $input_joiningDate;
    }

    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err) && empty($gender_err) && empty($birthDate_err) && empty($email_err) && empty($website_err) && empty($joiningDate_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO employees (name, address, salary, gender, birthDate, email, website, joiningDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ssssssss", $param_name, $param_address, $param_salary, $param_gender, $param_birthDate, $param_email, $param_website, $param_joiningDate);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
             $param_gender = $gender;
              $param_birthDate = $birthDate;
               $param_email = $email;
                $param_website = $website;
                 $param_joiningDate = $joiningDate;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    $mysqli->close();
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add employee record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Address</label>
                            <textarea name="address" class="form-control"><?php echo $address; ?></textarea>
                            <span class="help-block"><?php echo $address_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($salary_err)) ? 'has-error' : ''; ?>">
                            <label>Salary</label>
                            <input type="text" name="salary" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $salary_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($gender_err)) ? 'has-error' : ''; ?>">
                            <label>Gender</label>

                            <input type="radio" name="gender" value="female">Female
                            <input type="radio" name="gender" value="male">Male  
                            <span class="help-block"> <?php echo $gender_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($birthDate_err)) ? 'has-error' : ''; ?>">
                            <label>D.O.B</label>
                            <input type="date" name="birthDate" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $birthDate_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $email_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($website_err)) ? 'has-error' : ''; ?>">
                            <label>Website</label>
                            <input type="url" name="website" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $website_err;?></span>
                        </div>


                        <div class="form-group <?php echo (!empty($joiningDate_err)) ? 'has-error' : ''; ?>">
                            <label>Joining Date</label>
                            <input type="date" name="joiningDate" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $joiningDate_err;?></span>
                        </div>


                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>