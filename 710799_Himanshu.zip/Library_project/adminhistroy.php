<html>
<head>
 <link rel="stylesheet" type="text/css" href="libstyle.css"></link>
</head>
<body>
<h1>Admin Control</h1>
<table>
<tr>
<form action="data.php" method="post">
<input type="submit" value="View Profile"/>
</form>
</tr>
<tr>
<form action="showbook.php" method="post">
<input type="submit" value="Books Detail"/>
</form>
</tr>
<tr>
<form action="damagebookreport.php" method="post">
<input type="submit" value="Damaged Books Report"/>
</form>
</tr>
<tr>
<form action="dbadmin.php" method="post">
<input type="submit" value="Lost/Damaged Book"/>
</form>
</tr>
<tr>
<form action="login.php" method="post">
<input type="submit" value="Close"/>
</form>
</tr>
<img src="images\top6.jpg" width="100%" height="500px">
</body>
</html>