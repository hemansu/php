<html>
<head>
<link rel="stylesheet" type="text/css" href="libstyle.css"></link>
</head>
<body>
<h1>Track Book Location</h1>

<form action="locationresult.php" method="post">
<table>
<tr>
    <td><label>ISBN:</label></td>
    <td><input type="text" name="isbn" required/></td>
</tr>
</table><br>
<br>

<input type="submit" value="Locate"/>
</form>

<form action="userhistroy.php" method="post">
<input type="submit" value="Back"/>
</form>


</body>
</html>