-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2017 at 09:32 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Username` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `ISBN` char(14) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Cost` decimal(5,2) NOT NULL,
  `IsReserved` tinyint(1) NOT NULL,
  `Edition` int(11) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `CopyYr` decimal(4,0) NOT NULL,
  `ShelfID` int(11) DEFAULT NULL,
  `SubName` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ISBN`, `Title`, `Cost`, `IsReserved`, `Edition`, `Publisher`, `CopyYr`, `ShelfID`, `SubName`) VALUES
('000', 'Computer Architecture: A Quantitative Approach ', '24.95', 0, 4, 'Morgan Kaufmann', '2006', 321, 'Computer Architecture'),
('012', 'Digital Design and Computer Architecture', '52.57', 0, 2, ' Kaufmann', '2012', 311, 'Computer Design'),
('013', 'Computer Organization and Design', '75.74', 0, 5, 'Morgan Kaufmann', '2013', 312, 'Computer Architecture'),
('014', 'Psychology', '158.53', 0, 4, 'Pearson', '2014', 232, 'Psychology');

-- --------------------------------------------------------

--
-- Table structure for table `bookcopy`
--

CREATE TABLE `bookcopy` (
  `ISBN` char(14) NOT NULL,
  `CopyID` int(11) NOT NULL,
  `IsChecked` tinyint(1) NOT NULL DEFAULT '0',
  `IsHold` tinyint(1) NOT NULL DEFAULT '0',
  `IsDamaged` tinyint(1) NOT NULL DEFAULT '0',
  `FuRequester` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookcopy`
--

INSERT INTO `bookcopy` (`ISBN`, `CopyID`, `IsChecked`, `IsHold`, `IsDamaged`, `FuRequester`) VALUES
('000', 1, 1, 0, 0, 'rohan'),
('012', 2, 0, 0, 1, NULL),
('013', 3, 0, 1, 0, 'harpreet'),
('014', 1, 1, 0, 0, NULL),
('015', 2, 0, 1, 0, NULL),
('016', 1, 1, 0, 0, 'gagan');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `Username` varchar(15) NOT NULL,
  `ISBN` char(14) NOT NULL,
  `CopyID` int(11) NOT NULL,
  `IssueID` int(4) NOT NULL,
  `ExtenDate` date DEFAULT NULL,
  `IssueDate` date NOT NULL,
  `ReturnDate` date NOT NULL,
  `NumExten` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`Username`, `ISBN`, `CopyID`, `IssueID`, `ExtenDate`, `IssueDate`, `ReturnDate`, `NumExten`) VALUES
('harpreet', '014', 7, 82, '2015-02-05', '2015-02-05', '2015-02-19', 0),
('jaspreet', '012', 1, 45, '2015-01-03', '2015-01-03', '2015-01-17', 0),
('lovepal', '015', 2, 143, NULL, '2015-04-18', '2015-05-02', 0),
('prabh', '013', 3, 150, NULL, '2015-04-19', '2015-05-03', 0),
('rohan', '000', 1, 115, '2015-04-13', '2015-03-31', '2015-04-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_faculty`
--

CREATE TABLE `student_faculty` (
  `Username` varchar(15) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Email` varchar(30) NOT NULL,
  `Gender` char(1) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Course` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_faculty`
--

INSERT INTO `student_faculty` (`Username`, `Name`, `DOB`, `Email`, `Gender`, `Address`, `Course`) VALUES
('Gurpreet', 'Gurpreet Singh', '2017-10-10', 'mgopy@outlook.com', 'M', '118 Letty ave', 'College of Computing'),
('Harpreet', 'Harpreet Kaur', '0000-00-00', 'har@outlook.com', 'F', '71 creditstone rd', 'School of Electrical & Computer Engineering'),
('Jaspreet', 'Jaspreet kaur', '0000-00-00', 'jas123@gmail.com', 'F', '21 main street brampton', 'Computer Science'),
('Lovepal', 'Lovepal Singh', '1996-01-26', 'love@outlook.com', 'M', '118 Letty ave', 'School of Electrical & Computer Engineering'),
('Rohan', 'Rohan Sharma', '0000-00-00', 'rohan@outlook.com', 'M', '71 creditstone rd', ''),
('rupinder', 'Rupinder Kaur', '2017-10-02', 'rupi@gmail.com', 'F', '118 Letty ave', 'Medical college');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Username` varchar(15) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Username`, `Password`) VALUES
('11', '11'),
('Gurpreet', '1234'),
('Harpreet', 'harpreet90'),
('Jaspreet', 'jass123'),
('Lovepal', '890lovepal'),
('Manpreet', 'manuu'),
('manu', '123'),
('mm', '12'),
('Mohit', 'mohit'),
('Prabh', 'prabh1234'),
('Rohan', '123rohan'),
('rupinder', 'rupi1222');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ISBN`),
  ADD KEY `ShelfID` (`ShelfID`),
  ADD KEY `SubName` (`SubName`);

--
-- Indexes for table `bookcopy`
--
ALTER TABLE `bookcopy`
  ADD PRIMARY KEY (`ISBN`,`CopyID`);

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`Username`,`ISBN`,`CopyID`),
  ADD UNIQUE KEY `IssueID` (`IssueID`),
  ADD KEY `ISBN` (`ISBN`),
  ADD KEY `issue_ibfk_2` (`ISBN`,`CopyID`);

--
-- Indexes for table `student_faculty`
--
ALTER TABLE `student_faculty`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
