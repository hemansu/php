<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body style="font-family:Verdana;color:#aaaaaa;">

<div style="background-color:#e5e5e5;padding:15px;text-align:center;">
  <h1>Hello World</h1>
</div>

<div style="overflow:auto">
  <div class="menu">
    <div class="menuitem"><a href="add.php"> Add Employee</a></div>
    <div class="menuitem"><a href="update.php"> Update Employee</a></div>
    <div class="menuitem"><a href="delete.php"> Delete Employee</a></div>
<!--     <div class="menuitem">Link 4</div>
 -->  </div>

  <div class="main">
    <h2>Admin Dashboard</h2>
    <p> Complete Employee Record</p>



<?php 

include("databasefunctions.php");

$say = new ONE();
$say -> SelectAll();



 ?>
  </div>

  <div class="right">
    <h2>About</h2>
    <p>*********** ************* ************** **********</p>
  </div>
</div>

<div style="background-color:#e5e5e5;text-align:center;padding:10px;margin-top:7px;">© copyright w3schools.com</div>

</body>
</html>





