<?php
// Include config file
require_once 'databasefunctions.php';

// $say = new ONE();
// $say -> checkConnection();


$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname="EmployeeDB";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

 
// Define variables and initialize with empty values
$employeeId = $employeeName = $gender = $BirthDate= $Address = $City= $Province= 
$Postalcode= $Emailaddress= $websitelink= $Joiningdate = $Annualbasicpay="";
$employeeId_err = $employeeName_err = $gender_err = $BirthDate_err= $Address_err = $City_err= $Province_err= 
$Postalcode_err= $Emailaddress_err= $websitelink_err= $Joiningdate_err = $Annualbasicpay_err="";

 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_employeeId = trim($_POST["employeeId"]);
    if(empty($input_employeeId)){
        $employeeId_err = "Please enter a employeeId.";
    }  else{
        $employeeId = $input_employeeId;
    }
    
    // Validate employeeName
    $input_employeeName = trim($_POST["employeeName"]);
    if(empty($input_employeeName)){
        $employeeName_err = 'Please enter an employeeName.';     
    } else{
        $employeeName = $input_employeeName;
    }
    
    // Validate Address
    $input_Address = trim($_POST["Address"]);
    if(empty($input_Address)){
        $Address_err = "Please enter the Address";     
    }  else{
        $Address = $input_Address;
    }
    
    //  $input_City = trim($_POST["City"]);
    // if(empty($input_City){
    //     $City_err = "Please enter the City";     
    // }  else{
    //     $City = $input_City;
    // }

    //  $input_Province = trim($_POST["Province"]);
    // if(empty($input_Province){
    //     $Province_err = "Please enter the Province";     
    // }  else{
    //     $Province = $input_Province;
    // }

    //  $input_City = trim($_POST["City"]);
    // if(empty($input_City){
    //     $City_err = "Please enter the City";     
    // }  else{
    //     $City = $input_City;
    // }

    //  $input_City = trim($_POST["City"]);
    // if(empty($input_City){
    //     $City_err = "Please enter the City";     
    // }  else{
    //     $City = $input_City;
    // }
    // Check input errors before inserting in database
    if(empty($employeeId_err) && empty($employeeName_err) && empty($Address_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Employee_Table (employeeId, employeeName, Address) VALUES (?, ?, ?)";

        if($stmt = $conn->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("iss", $param_employeeId, $param_employeeName, $param_Address);
            
            // Set parameters
            $param_employeeId = $employeeId;
            $param_employeeName = $employeeName;
            $param_Address = $Address;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){

echo '<script type="text/javascript">alert("hello!");</script>';
                // Records created successfully. Redirect to landing page
                header("location: admin.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    // $mysqli->close();

        $conn->close();

}
?>
 
<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add employee record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($employeeId_err)) ? 'has-error' : ''; ?>">
                            <label>Id</label>
                            <input type="text" name="employeeId" class="form-control" value="<?php echo $employeeId; ?>">
                            <span class="help-block"><?php echo $employeeId_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($employeeName_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <textarea name="employeeName" class="form-control"><?php echo $employeeName; ?></textarea>
                            <span class="help-block"><?php echo $employeeName_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($Address_err)) ? 'has-error' : ''; ?>">
                            <label>Address</label>
                            <input type="text" name="Address" class="form-control" value="<?php echo $Address; ?>">
                            <span class="help-block"><?php echo $Address_err;?></span>
                        </div>
                       <!--  <div class="form-group <?php echo (!empty($employeeId_err)) ? 'has-error' : ''; ?>">
                            <label>Id</label>
                            <input type="text" name="employeeId" class="form-control" value="<?php echo $employeeId; ?>">
                            <span class="help-block"><?php echo $employeeId_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($employeeId_err)) ? 'has-error' : ''; ?>">
                            <label>Id</label>
                            <input type="text" name="employeeId" class="form-control" value="<?php echo $employeeId; ?>">
                            <span class="help-block"><?php echo $employeeId_err;?></span>
                        </div> -->
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>