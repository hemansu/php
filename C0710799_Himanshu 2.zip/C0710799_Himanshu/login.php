<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- <link rel="stylesheet" type="text/css" href="login.js"> -->
     <link rel="stylesheet" type="text/css" href="stylesheet.css" >
<title>ADMIN LOGIN</title>
</head>

</style>
<body>

<div class="container">
<div class="header">
 <h1>Admin Login</h1>
 </div>

 <form name="login" onsubmit="return validateForm() ;" method="post">

 <ul>
 <li>Username: <input class="username" type="text" name="username" placeholder="User Name" onfocus="this.value=''">
 </li>

 <li>Password: <input class="password" type="password" name="password" placeholder="Password" onfocus="this.value=''">
 </li>
 </ul>

<input type="button" class="submit" value="Sign In" name="submit" onclick="validate()">
</form>
</div>

<script>




var count= 2;
function validate()
{
     var un = document.login.username.value;
     var pw = document.login.password.value;
     var valid = false;
     var usernameArray = ["abc", "admin"];
     var passwordArray = ["123", "admin@123"];
     for (var i = 0; i < usernameArray.length; i++)
 {
     if ((un == usernameArray[i]) && (pw == passwordArray[i]))
     {
          valid = true;
          break;

     }
}

     if (valid)
     {
          alert("Login was successful");
             window.open("http://localhost/him/C0710799_Himanshu/admin.php" , '_blank');

        //  window.location = "www.google.com";
          return false;
     }
     var again = " tries";
     if (count ==1)
     {
          again = " try"
     }
     if (count >= 1)
     {
          alert("Wrong password or username")
          count--;
     }
     else
     {
          alert("Incorrect password or username you are now blocked");
          document.login.username.value = "You are now Blocked";
          document.login.password.value = "Fool you can't see this";
          document.login.username.disabled = true;
          document.login.password.disabled = true;
          return false;
     }
}
</script>


</body>
</html>